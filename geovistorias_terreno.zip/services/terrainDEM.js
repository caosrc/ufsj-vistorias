// ── Terrarium DEM — AWS Elevation Tiles (gratuito, sem API key) ──
// URL: https://s3.amazonaws.com/elevation-tiles-prod/terrarium/{z}/{x}/{y}.png
// Fórmula: altitude = (R × 256 + G + B/256) − 32768   (precisão ~10cm)
//
// Zoom vs resolução (equador):
//   z=12 → ~40m/pixel   z=13 → ~20m/pixel   z=14 → ~10m/pixel

const tileCache = new Map()
const MAX_CACHE = 300

function latLngToTileXY(lat, lng, z) {
  const n   = Math.pow(2, z)
  const x   = Math.floor((lng + 180) / 360 * n)
  const rad = lat * Math.PI / 180
  const y   = Math.floor((1 - Math.log(Math.tan(rad) + 1 / Math.cos(rad)) / Math.PI) / 2 * n)
  return { x: Math.max(0, x), y: Math.max(0, y) }
}

function tilePixelOffset(lat, lng, tileX, tileY, z) {
  const n   = Math.pow(2, z)
  const px  = ((lng + 180) / 360 * n - tileX) * 256
  const rad = lat * Math.PI / 180
  const py  = ((1 - Math.log(Math.tan(rad) + 1 / Math.cos(rad)) / Math.PI) / 2 * n - tileY) * 256
  return {
    px: Math.max(0, Math.min(255, Math.floor(px))),
    py: Math.max(0, Math.min(255, Math.floor(py))),
    fpx: px - Math.floor(px),
    fpy: py - Math.floor(py),
  }
}

function decodeTerrarium(r, g, b) {
  return (r * 256 + g + b / 256) - 32768
}

async function loadTilePixels(z, x, y) {
  const key = `${z}/${x}/${y}`
  if (tileCache.has(key)) return tileCache.get(key)

  const url = `https://s3.amazonaws.com/elevation-tiles-prod/terrarium/${z}/${x}/${y}.png`

  const data = await new Promise((resolve, reject) => {
    const img = new Image()
    img.crossOrigin = 'anonymous'
    img.onload = () => {
      const canvas = document.createElement('canvas')
      canvas.width = 256; canvas.height = 256
      const ctx = canvas.getContext('2d')
      ctx.drawImage(img, 0, 0)
      resolve(ctx.getImageData(0, 0, 256, 256).data)
    }
    img.onerror = reject
    img.src = url
  })

  // LRU simples
  if (tileCache.size >= MAX_CACHE) {
    const firstKey = tileCache.keys().next().value
    tileCache.delete(firstKey)
  }
  tileCache.set(key, data)
  return data
}

// Interpolação bilinear dentro do tile para suavizar
function bilinearElevation(data, fpx, fpy, px, py) {
  function px4(x, y) {
    const cx = Math.max(0, Math.min(255, x))
    const cy = Math.max(0, Math.min(255, y))
    const i  = (cy * 256 + cx) * 4
    return decodeTerrarium(data[i], data[i+1], data[i+2])
  }
  const e00 = px4(px,   py)
  const e10 = px4(px+1, py)
  const e01 = px4(px,   py+1)
  const e11 = px4(px+1, py+1)
  return e00*(1-fpx)*(1-fpy) + e10*fpx*(1-fpy) + e01*(1-fpx)*fpy + e11*fpx*fpy
}

// Calcula o zoom ideal baseado na extensão da linha (em metros)
function zoomForExtent(extentM) {
  if (extentM < 800)   return 15
  if (extentM < 3000)  return 14
  if (extentM < 8000)  return 13
  return 12
}

// ── API pública ───────────────────────────────────────────────

// Busca elevação de um único ponto (lat, lng) com zoom z
export async function getElevationDEM(lat, lng, z = 14) {
  const { x, y } = latLngToTileXY(lat, lng, z)
  const data = await loadTilePixels(z, x, y)
  const { px, py, fpx, fpy } = tilePixelOffset(lat, lng, x, y, z)
  return bilinearElevation(data, fpx, fpy, px, py)
}

// Busca elevações para um array de pontos [ [lng, lat], ... ]
// Agrupa por tile para minimizar requisições HTTP
export async function getElevationsBatchDEM(points, extentM = null) {
  if (!points || points.length === 0) return []

  const z = extentM ? zoomForExtent(extentM) : 13

  // Agrupa pontos por tile
  const tileKeys = new Map()
  for (let i = 0; i < points.length; i++) {
    const [lng, lat] = points[i]
    const { x, y } = latLngToTileXY(lat, lng, z)
    const key = `${z}/${x}/${y}`
    if (!tileKeys.has(key)) tileKeys.set(key, { x, y, z })
  }

  // Carrega todos os tiles únicos em paralelo
  await Promise.all(
    [...tileKeys.entries()].map(([key, { x, y, z }]) =>
      loadTilePixels(z, x, y).catch(() => null)
    )
  )

  // Decodifica cada ponto (bilinear)
  return points.map(([lng, lat]) => {
    const { x, y }            = latLngToTileXY(lat, lng, z)
    const data                = tileCache.get(`${z}/${x}/${y}`)
    if (!data) return null
    const { px, py, fpx, fpy } = tilePixelOffset(lat, lng, x, y, z)
    const h = bilinearElevation(data, fpx, fpy, px, py)
    // sanity check: valores fora de [-500, 9000] indicam oceano/erro
    return (h > -500 && h < 9000) ? h : null
  })
}

// Versão com fallback: tenta DEM, cai na API do backend se falhar
export async function getElevationsBatchWithFallback(points, fallbackFn, extentM = null) {
  try {
    const demResults = await getElevationsBatchDEM(points, extentM)
    // Se > 80% dos valores vieram OK, usa DEM
    const valid = demResults.filter(v => v !== null).length
    if (valid / demResults.length >= 0.8) {
      // Preenche nulos com interpolação linear dos vizinhos
      for (let i = 0; i < demResults.length; i++) {
        if (demResults[i] !== null) continue
        let lo = i - 1, hi = i + 1
        while (lo >= 0 && demResults[lo] === null) lo--
        while (hi < demResults.length && demResults[hi] === null) hi++
        const vlo = lo >= 0 ? demResults[lo] : null
        const vhi = hi < demResults.length ? demResults[hi] : null
        if (vlo !== null && vhi !== null) {
          const t = (i - lo) / (hi - lo)
          demResults[i] = vlo + (vhi - vlo) * t
        } else {
          demResults[i] = vlo ?? vhi ?? 0
        }
      }
      return { elevations: demResults, source: 'DEM Terrarium 10m' }
    }
  } catch (_) {}

  // Fallback para API do backend
  try {
    const elevations = await fallbackFn(points)
    return { elevations, source: 'API SRTM 90m' }
  } catch (err) {
    throw err
  }
}
